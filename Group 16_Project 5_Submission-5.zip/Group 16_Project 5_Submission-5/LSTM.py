import os
import re
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.preprocessing import LabelEncoder
from collections import Counter
from google.colab import drive
from sklearn.utils.class_weight import compute_class_weight
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.layers import Input, Embedding, LSTM, Conv1D, GlobalMaxPooling1D, Dense, Dropout, concatenate
from tensorflow.keras.models import Model

# Mount Google Drive
drive.mount('/content/drive')

# Constants
MAX_SEQUENCE_LENGTH = 1000
MAX_NUM_WORDS = 10000
EMBEDDING_DIM = 128
LSTM_UNITS = 128
BATCH_SIZE = 32
EPOCHS = 50

def load_and_preprocess_data(directory):
    opcodes = []
    labels = []
    for filename in os.listdir(directory):
        if filename.endswith('.opcode'):
            label = filename.split('_')[0]
            with open(os.path.join(directory, filename), 'r', encoding='utf-8') as f:
                opcode_text = f.read()
            opcode_text = re.sub(r';.*', '', opcode_text)
            tokens = re.findall(r'\b[A-Z]+\b', opcode_text.upper())
            opcodes.append(' '.join(tokens[:MAX_SEQUENCE_LENGTH]))
            labels.append(label)
    return opcodes, labels

def create_advanced_model(max_words, sequence_length, embedding_dim, num_classes):
    input_layer = Input(shape=(sequence_length,))
    embedding = Embedding(max_words, embedding_dim, input_length=sequence_length)(input_layer)

    # CNN branch
    conv1 = Conv1D(64, 3, activation='relu')(embedding)
    conv2 = Conv1D(64, 4, activation='relu')(embedding)
    conv3 = Conv1D(64, 5, activation='relu')(embedding)

    pool1 = GlobalMaxPooling1D()(conv1)
    pool2 = GlobalMaxPooling1D()(conv2)
    pool3 = GlobalMaxPooling1D()(conv3)

    # LSTM branch
    lstm = LSTM(LSTM_UNITS, return_sequences=True)(embedding)
    lstm = LSTM(LSTM_UNITS)(lstm)

    # Merge branches
    merged = concatenate([pool1, pool2, pool3, lstm])

    dense1 = Dense(128, activation='relu')(merged)
    dropout1 = Dropout(0.5)(dense1)
    dense2 = Dense(64, activation='relu')(dropout1)
    dropout2 = Dropout(0.5)(dense2)
    output = Dense(num_classes, activation='softmax')(dropout2)

    model = Model(inputs=input_layer, outputs=output)
    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return model

def custom_train_test_split(X, y, test_size=0.2, random_state=None):
    if random_state is not None:
        np.random.seed(random_state)

    classes, class_counts = np.unique(y, return_counts=True)
    train_indices = []
    test_indices = []

    for cls, count in zip(classes, class_counts):
        cls_indices = np.where(y == cls)[0]
        np.random.shuffle(cls_indices)

        if count == 1:
            train_indices.extend(cls_indices)
        else:
            split = max(1, int(count * (1 - test_size)))
            train_indices.extend(cls_indices[:split])
            test_indices.extend(cls_indices[split:])

    np.random.shuffle(train_indices)
    np.random.shuffle(test_indices)

    X_train = X[train_indices]
    X_test = X[test_indices]
    y_train = y[train_indices]
    y_test = y[test_indices]

    return X_train, X_test, y_train, y_test

def advanced_data_augmentation(X, y):
    augmented_X = []
    augmented_y = []
    for x, label in zip(X, y):
        augmented_X.append(x)
        augmented_y.append(label)

        # Add slightly modified version
        modified = x + np.random.normal(0, 0.01, x.shape)
        augmented_X.append(modified)
        augmented_y.append(label)

        # Randomly insert or delete a small number of opcodes
        modified = list(x)
        num_changes = np.random.randint(1, 6)
        for _ in range(num_changes):
            if np.random.rand() > 0.5 and len(modified) < MAX_SEQUENCE_LENGTH:  # Insert
                idx = np.random.randint(0, len(modified))
                modified.insert(idx, np.random.choice(x))
            elif len(modified) > 1:  # Delete
                idx = np.random.randint(0, len(modified))
                del modified[idx]

        # Pad or truncate the sequence to maintain consistent length
        if len(modified) < MAX_SEQUENCE_LENGTH:
            modified.extend([0] * (MAX_SEQUENCE_LENGTH - len(modified)))
        else:
            modified = modified[:MAX_SEQUENCE_LENGTH]

        augmented_X.append(modified)
        augmented_y.append(label)

    return np.array(augmented_X), np.array(augmented_y)

# Main execution
print("Loading and preprocessing data...")
OPCODE_DIR = '/content/drive/MyDrive/Extracted_OPCODES'
opcodes, labels = load_and_preprocess_data(OPCODE_DIR)

print("Tokenizing opcodes...")
tokenizer = Tokenizer(num_words=MAX_NUM_WORDS)
tokenizer.fit_on_texts(opcodes)
sequences = tokenizer.texts_to_sequences(opcodes)
data = pad_sequences(sequences, maxlen=MAX_SEQUENCE_LENGTH)

label_encoder = LabelEncoder()
labels = label_encoder.fit_transform(labels)

num_classes = len(label_encoder.classes_)
print(f"Number of classes: {num_classes}")

# Print class distribution
class_distribution = Counter(labels)
print("\nClass distribution:")
for label, count in class_distribution.items():
    print(f"{label_encoder.classes_[label]}: {count}")

X_train, X_test, y_train, y_test = custom_train_test_split(data, labels, test_size=0.2, random_state=42)

print(f"\nTraining set size: {len(X_train)}")
print(f"Test set size: {len(X_test)}")

# Compute class weights
class_weights = compute_class_weight('balanced', classes=np.unique(y_train), y=y_train)
class_weight_dict = dict(enumerate(class_weights))

# Apply advanced data augmentation
X_train_augmented, y_train_augmented = advanced_data_augmentation(X_train, y_train)

print("Creating and training the advanced model...")
model = create_advanced_model(MAX_NUM_WORDS, MAX_SEQUENCE_LENGTH, EMBEDDING_DIM, num_classes)

# Callbacks
early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=5, min_lr=1e-6)

history = model.fit(
    X_train_augmented, y_train_augmented,
    batch_size=BATCH_SIZE,
    epochs=EPOCHS,
    validation_split=0.1,
    class_weight=class_weight_dict,
    callbacks=[early_stopping, reduce_lr],
    verbose=1
)

print("\nEvaluating the model...")
loss, accuracy = model.evaluate(X_test, y_test, verbose=0)
print(f"Test accuracy: {accuracy:.4f}")

y_pred = model.predict(X_test)
y_pred_classes = np.argmax(y_pred, axis=1)

print("\nClassification Report:")
from sklearn.metrics import classification_report
unique_classes = np.unique(np.concatenate([y_test, y_pred_classes]))
target_names = label_encoder.classes_[unique_classes]
print(classification_report(y_test, y_pred_classes, target_names=target_names, zero_division=1))

# Save the model
MODEL_PATH = '/content/drive/MyDrive/advanced_malware_model.h5'
model.save(MODEL_PATH)
print(f"Model saved to {MODEL_PATH}")

# Plot training history
import matplotlib.pyplot as plt

plt.figure(figsize=(12, 4))
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Model Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Model Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()

plt.tight_layout()
plt.show()

print("Training visualization complete.")

# Print classes present in the test set
print("\nClasses present in the test set:")
for class_name in target_names:
    print(class_name)

# Print classes not present in the test set
missing_classes = set(label_encoder.classes_) - set(target_names)
print("\nClasses not present in the test set:")
for class_name in missing_classes:
    print(class_name)