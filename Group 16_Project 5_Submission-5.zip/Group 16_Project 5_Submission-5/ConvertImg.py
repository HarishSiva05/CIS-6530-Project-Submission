import os
from PIL import Image
import numpy as np

def is_hex(value):
    """
    Checks if a string is a valid hexadecimal number.
    """
    try:
        int(value, 16)
        return True
    except ValueError:
        return False

def opcode_to_image(opcode_path, output_path, img_size=(64, 64)):
    """
    Converts an OpCode file to a grayscale image by normalizing or clipping values to fit uint8.

    Args:
        opcode_path (str): Path to the OpCode file.
        output_path (str): Path to save the output image.
        img_size (tuple): Desired image size (width, height).
    """
    try:
        with open(opcode_path, 'r') as f:
            data = f.read()

        # Extract only valid hexadecimal values
        byte_values = [int(byte, 16) for byte in data.split() if is_hex(byte)]

        if len(byte_values) == 0:
            print(f"No valid hex values found in {opcode_path}. Skipping.")
            return

        # Normalize or clip values to the uint8 range (0–255)
        byte_array = np.array(byte_values, dtype=np.float32)
        byte_array = np.clip(byte_array, 0, 255).astype(np.uint8)

        # Reshape to the closest possible 2D shape
        side_length = int(np.ceil(np.sqrt(len(byte_array))))
        padded_array = np.zeros((side_length * side_length,), dtype=np.uint8)
        padded_array[:len(byte_array)] = byte_array
        reshaped_array = padded_array.reshape((side_length, side_length))

        # Resize the array to the desired image size
        image = Image.fromarray(reshaped_array)
        image = image.resize(img_size, Image.BICUBIC)
        image.save(output_path)
        print(f"Saved image: {output_path}")
    except Exception as e:
        print(f"Error processing file {opcode_path}: {e}")

def process_opcodes(input_dir, output_dir, img_size=(64, 64)):
    """
    Processes all OpCode files in the input directory and converts them to images.

    Args:
        input_dir (str): Directory containing OpCode files.
        output_dir (str): Directory to save the generated images.
        img_size (tuple): Desired image size (width, height).
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for file_name in os.listdir(input_dir):
        file_path = os.path.join(input_dir, file_name)
        if os.path.isfile(file_path) and file_name.endswith('.opcode'):
            output_path = os.path.join(output_dir, f"{os.path.splitext(file_name)[0]}.png")
            opcode_to_image(file_path, output_path, img_size)

if __name__ == "__main__":
    # Paths to input and output folders
    input_folder = os.path.expanduser("C:\\Users\\Harish\\Desktop\\Extracted_OPCODES")
    output_folder = os.path.expanduser("C:\\Users\\Harish\\Desktop\\IMG")
    
    # Convert OpCode files to images
    process_opcodes(input_folder, output_folder, img_size=(64, 64))
