import os
from PIL import Image, ImageOps
import random

def augment_image(image_path, output_dir):
    """
    Perform augmentations on a single image and save the augmented images.

    Args:
        image_path (str): Path to the input image.
        output_dir (str): Directory to save the augmented images.
    """
    try:
        img = Image.open(image_path)
        print(f"Processing: {image_path}")
        
        # Ensure output directory exists
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # Augmentations
        base_name = os.path.splitext(os.path.basename(image_path))[0]

        # Flip
        flipped_img = ImageOps.mirror(img)
        flipped_img.save(os.path.join(output_dir, f"{base_name}_flipped.png"))

        # Rotate
        rotated_img = img.rotate(random.randint(-30, 30))
        rotated_img.save(os.path.join(output_dir, f"{base_name}_rotated.png"))

        # Grayscale
        grayscale_img = ImageOps.grayscale(img)
        grayscale_img.save(os.path.join(output_dir, f"{base_name}_grayscale.png"))

        # Resize (Example)
        resized_img = img.resize((128, 128))
        resized_img.save(os.path.join(output_dir, f"{base_name}_resized.png"))

        print(f"Augmented images saved for: {image_path}")
    except Exception as e:
        print(f"Error processing {image_path}: {e}")

def process_images(input_dir, output_dir):
    """
    Process all images in the input directory and apply augmentations.

    Args:
        input_dir (str): Directory containing the input images.
        output_dir (str): Directory to save the augmented images.
    """
    if not os.path.exists(input_dir):
        print(f"Error: The input directory '{input_dir}' does not exist.")
        return

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Iterate over all files in the input directory
    for file_name in os.listdir(input_dir):
        file_path = os.path.join(input_dir, file_name)
        if os.path.isfile(file_path) and file_name.lower().endswith(('png', 'jpg', 'jpeg')):
            augment_image(file_path, output_dir)

if __name__ == "__main__":
    # Hardcoded input and output directories
    input_directory = r"C:\\Users\\Harish\\Desktop\\IMG_64"
    output_directory = r"C:\\Users\\Harish\\Desktop\\IMG_AUG"

    # Process all images
    process_images(input_directory, output_directory)
